=== Addons for KingComposer ===
Contributors: themebon
Donate link: https://themebon.com/
Tags: addons, king composer plugin, king composer shortcode, wordpress shortcode, vc extensions, flip box, flip box 3d, before after, responsive, hover effects, image hover effects, info box, features, shortcode, promo box, service box, service shortcode, powerfull shortcode, button style, before after, css3 hover effects, top image effect, best king composer addon,best king composer extensions, 2017 shortcodes, ultra modern shortcodes, 3d effect, 3d, responsive, responsive image effects, awesome css3 effects, awesome image effects, image style, modern style, CSS Animation, css effects, css3, responsive plugin, css3 effects, effects, effects css3, responsive images, css3 powered effects, effects hover, hover, hover css effects, hover effects, mouse over top hover effects wordpress, animated image wp, 3d style effects, top image effects for wordpress, top image caption for wordpress, wordpress image hover plugin, image styles wordpress, best photo caption. 
Requires at least: 4.0.1
Tested up to: 4.7
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==


>[Live Demo ](http://themebon.com/demos?theme=vc-shortcodes "Addons for KingComposer")



Addons for KingComposer is an impressive modern shortcode collections for KingComposer page builder plugin with unlimited customization.

You can build amazing professional layouts for your site with tons of powerfull shortcodes. 


Addons for KingComposer plugin runs with KingComposer page builder plugin   https://wordpress.org/plugins/kingcomposer/



<strong>Shortcode List:</strong> 
<ul>
     <li>Hover Effects</li>
     <li>Before After</li>
     <li>Flip Box 3D</li>
     <li>Flip Box</li>
     <li>Info Box</li>
     <li>Promo Box</li>
     <li>Service Box</li>
     <li>Coming more</li>
</ul>


<strong>Features</strong>
<ul>
    <li>Super easy Installation.</li>
    <li>Unlimited Colors.</li>
    <li>Tons of customization options.</li>
    <li>Powerfull Shortcodes.</li>
    <li>SEO friendly.</li>
    <li>Easy user interface.</li>
    <li>User friendly customization. </li>
    <li>All Major browser supported. </li>

</ul>


Tags: king composer plugin, king composer shortcode, wordpress shortcode, vc extensions, flip box, flip box 3d, before after, responsive, hover effects, image hover effects, info box, features, shortcode, promo box, service box, service shortcode, powerfull shortcode, button style, before after, css3 hover effects, top image effect, best king composer addon,best king composer extensions, 2017 shortcodes, ultra modern shortcodes, 3d effect, 3d, responsive, responsive image effects, awesome css3 effects, awesome image effects, image style, modern style, CSS Animation, css effects, css3, responsive plugin, css3 effects, effects, effects css3, responsive images, css3 powered effects, effects hover, hover, hover css effects, hover effects, mouse over top hover effects wordpress, animated image wp, 3d style effects, top image effects for wordpress, top image caption for wordpress, wordpress image hover plugin, image styles wordpress, best photo caption.


== Installation ==

Installing this plugin as regular wordpress plugin. First you need to install King Composer page builder plugin then install Amazing Shortcodes For Visual Composer.

This addon plugin works like other page builder addon plugin. Go to new page then click on Visual Composer builder then click on Add Element you should see Amazing Shortcodes menu as Name "Amazing Shortcodes" on Menu Top, click on it you will see shortcode item list.



== Screenshots ==

1. screenshot 1
2. screenshot 2
3. screenshot 3
4. screenshot 4


== Changelog ==

= 1.0.0 =
* First Release


== Upgrade Notice ==

= 1.0.0 =
* First Release