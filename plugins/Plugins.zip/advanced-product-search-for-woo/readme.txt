﻿=== Advanced Product Search For WooCommerce ===
Contributors: aThemeArt
Tags:  woocommerce search page, woocommerce search form, woocommerce search filter, woocommerce search products, woocommerce search content, woocommerce search autocomplete, woocommerce advanced search, woocommerce search category, woocommerce search product attributes, woocommerce search by tag, woocommerce search by brand, woocommerce predictive, woocommerce live search, woocommerce single product search, woocommerce site search, woocommerce search, ajax, search, woocommerce, products, themes, woocommerce search by sku, woocommerce search results, woocommerce search shortcode , e-commerce, shop, ajax search, instant search, premium, aThemeArt, autocomplete, autosuggest, better search, category search, custom search, highlight terms, Live Search, Predictive Search, product search, relevant search, search highlight, search product, suggest, typeahead, WooCommerce Plugin, woocommerce product search, woocommerce search, wordpress ecommerce
Requires at least: 4.6
Tested up to:  5.7.4
Stable tag: 1.0.2
Requires PHP: 5.3.2
Donate link: https://athemeart.com/downloads/advanced-product-search-for-woo/
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Popup Cart Lite for WooCommerce for WooCommerce plugin that displays popup cart for add to cart action.

== Description ==

[__Live Demo__](https://eds.edatastyle.com/demo/aspw/).

[__Check Woocommerce Search Plugin Pro __](https://www.athemeart.com/downloads/advanced-product-search-for-woo/).

Advanced Product search for woocommerce – powerful instant search plugin for WooCommerce.You just got to install and simply begin typewriting and you'll instantly see the product list that you simply search.

It create a simple search box that shows you live search results, by suggesting you product from your WooCommerce shop that match your search out criteria.

No coding for knowledge needed for making any search kind for your product search.

Download, install and victimisation the plugin is simple and fun, you'll be able to produce, customise and build the attractive search forms for your product search and may place it on any of the page or in elementor ,visual composer, kingcomposer, widget .

Plugin have the unlimited color schemes of your selections to match your theme.


**Features provided with this plugin:**
* Products search – Search across all your WooCommerce products
* Widget and shortcodes to show your WooCommerce searchform in anywhere you want in your WooCommerce site..
* Search in – Search in product title, content, excerpt, categories, tags and sku. Or just in some of them
* Product image – Each search result contains product image
* Works for both simple and variable products.
* Filter by Ascending and Descending
* Enable or disable searches by product category and tag.
* you can preview of advanced searcher option as per your setting.
* you can apply custom CSS for advanced searcher option.


[__Pro version__](https://athemeart.com/downloads/advanced-product-search-for-woo/).


**Premium Features:**
* Widget, elementor ,visual composer, kingcomposer and shortcodes to show your WooCommerce searchform in anywhere you want in your WooCommerce site..
* Advanced settings page with lot of options
* Unlimited color schemes
*  Visibility/stock status option – choose what catalog visibility and stock status must be for product to displayed in search results
* Add to cart button in search results
* Search in WooCommerce product excerpt
* Search in WooCommerce product content
* Search in WooCommerce product categories
* Search in WooCommerce product tags
* An awesome feature that your competitors may not have.


the plugins tested or theme compatibility with Hello Elementor, OceanWP, Hestia, Storefront, shopstore, Avada, BeTheme, The7, Flatsome, Enfold, X | The Theme, Porto , WoodMart and may more .... 

== Installation ==

= Automatic installation =

Install Advanced Product Search For Woo just like any other WordPress plugin.  
[Installing Plugins] (https://codex.wordpress.org/Managing_Plugins)


== Frequently Asked Questions ==

= Will this plugin work with my theme? =
Yes, it will work with any theme, but may require some styling to make it match nicely.

== Screenshots ==

1. preview screen 0
2. Plugins Options 1 
3. Plugins Options 2
4. Plugins Options 3

== Upgrade Notice ==

= 1.0.1 =
* pro link updated.

= 1.0.1 =
* Initial release.


== Changelog ==

= 1.0.1 =
* pro link updated.

= 1.0.0 =
* Initial release.