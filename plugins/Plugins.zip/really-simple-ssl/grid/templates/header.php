<?php defined('ABSPATH') or die("you do not have access to this page!"); ?>

<div class="rsssl-secondary-header-item">
	<div class="rsssl-save-settings-feedback" style="display: none;">
		<?php _e("Save settings" , "really-simple-ssl") ?>
	</div>
    <div class="rsssl-instructions">{instructions}</div>
</div>